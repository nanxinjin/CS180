
public class ArrayElementException extends Exception{
	public ArrayElementException(String message) {
		super(message);
	}
}
