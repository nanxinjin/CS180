
public class IllegalDivisionByZero extends Exception{
	public IllegalDivisionByZero(String message) {
	 
	 super(message);
 }
}
